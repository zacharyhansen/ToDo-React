import React, { Component } from 'react';
import './App.css';
import ToDoList from './Components/ToDoList.js';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <p>
            ToDo List
          </p>
          <ToDoList />
        </header>
      </div>
    );
  }
}

export default App;
