import React from 'react';
import { List, Button } from 'semantic-ui-react';

const ToDoItem = ({ todo, completeTask, index }) => {
  if (todo[1]) {
    return (
      <div>
        <List.Item>{todo[0]}</List.Item>
      </div>
    )
  }

  return (
    <span>
      <List.Item>{todo[0]}</List.Item>
      <Button onClick={() => completeTask(index)}>Complete</Button>
    </span>
  )
}

export default ToDoItem;