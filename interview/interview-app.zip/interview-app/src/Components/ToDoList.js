import React from 'react';
import ToDoItem from './ToDoItem';
import { List } from 'semantic-ui-react';
import ProgressBar from './ProgressBar.js';
import AddItem from './AddItem.js';

class ToDoList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [
        ['Mow Lawn', true],
        ['Clean Room', false],
        ['Feed Dog', false],
      ],
      numOfComplete: 1,
    }
    this.completeTask = this.completeTask.bind(this);
    this.addTask = this.addTask.bind(this);
  }

  completeTask(index) {
    const todos = this.state.todos;
    todos[index][1] = true;
    this.setState({
      todos,
      numOfComplete: this.state.numOfComplete + 1,
    })
  }

  addTask(task) {
    const todos = this.state.todos;
    todos.push([task, false]);
    this.setState({
      todos,
    })
  }

  render() {
    return (
      <div>
        <ProgressBar complete={this.state.numOfComplete} total={this.state.todos.length} />
        {this.state.todos.map((todo, index) => <ToDoItem todo={todo} completeTask={this.completeTask} index={index} />)}
        <AddItem addTask={this.addTask} />
      </div>
    )
  }
}

export default ToDoList;