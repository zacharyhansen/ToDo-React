import React from 'react';
import { Progress } from 'semantic-ui-react';

const ProgressBar = ({ complete, total }) => {
  return (
    <Progress percent={12} />
  )
}

export default ProgressBar;